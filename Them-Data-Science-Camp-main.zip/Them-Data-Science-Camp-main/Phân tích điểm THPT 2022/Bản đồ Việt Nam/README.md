# Biểu diễn dữ liệu dưới dạng Bản đồ Việt Nam

Để phục vụ cho quá trình phân tích điểm trung bình của 63 tỉnh thành của Việt Nam, mình đã sử dụng thư viện **sf** và **tidyverse** và kết hợp với dữ liệu bản đồ Việt Nam trích nguồn từ **GADM** và cuối cùng là tạo ra plot sử dụng R </br>

Đây là bản đồ phân bố điểm trung bình của 63 tỉnh thành của Việt Nam:</br>
![alt text](https://github.com/andythetechnerd03/Them-Data-Science-Camp/blob/main/Ph%C3%A2n%20t%C3%ADch%20%C4%91i%E1%BB%83m%20THPT%202022/B%E1%BA%A3n%20%C4%91%E1%BB%93%20Vi%E1%BB%87t%20Nam/000003.png)
