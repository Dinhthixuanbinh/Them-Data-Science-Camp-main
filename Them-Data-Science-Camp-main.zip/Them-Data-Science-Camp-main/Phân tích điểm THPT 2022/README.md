# Phân tích điểm thi THPT Quốc Gia 2022 bằng Python, R
</br>
Đây là một phần trong Project của môn ADY201m trong đó yêu cầu của Project là phân tích điểm thi THPT Quốc Gia 2022 bằng Python, R và lập ra các biểu đồ sử dụng thư viện Plotly, Matplotlib và ggplot của R.
