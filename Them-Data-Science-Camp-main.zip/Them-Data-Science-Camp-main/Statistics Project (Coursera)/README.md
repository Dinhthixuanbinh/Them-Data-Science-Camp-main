# Statistics Project for Coursera
Analysing house prices in Boston and test a couple of hypothesis. </br>
I got 23/24 points peer-reviewed. </br>
Enjoy! (for reference only, it's best if you don't copy this project into your own!)
