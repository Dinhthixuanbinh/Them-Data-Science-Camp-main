Let's look at students list that failed a subject to due to being over absent, which, in this case, is over 20% and let's see how the hell they even fail in the first place.</br>
Here, the list is from Summer 2022 semester. </br>
Keep in mind that this is the list publicly uploaded by school so I did not hack into the system or anything like that. </br>
Have fun!
