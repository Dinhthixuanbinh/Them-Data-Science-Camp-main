# Introduction

This is a part of a Python project that I did on IBM Data Science Specialization. In this notebook I extract the historical data of Tesla and GameStop</br>
stock over the years from MacroTrend using BeautifulSoup and plot them using Plotly.</br>
</br>
Here's the link for reference: https://cf-courses-data.s3.us.cloud-object-storage.appdomain.cloud/IBMDeveloperSkillsNetwork-PY0220EN-SkillsNetwork/labs/project/stock.html </br>
</br>
https://www.macrotrends.net/stocks/charts/TSLA/tesla/revenue </br>
